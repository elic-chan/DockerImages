#!/bin/sh
install_mode=$1
install_dir=$2

java_path=`which java`
java_path1=../jre/bin/java
platform=`uname -m`
if [ "$install_mode"x = "CONSOLE"x ] ; then
	if [ "$platform"x = "aarch64"x ] || [ "$platform"x = "mips64el"x ] ; then
        sed -i "s%$java_path1%$java_path%g" $install_dir/Uninstall/Uninstaller.lax
	fi
fi
