#!/bin/sh 

# Kingbase cluster init script for Linux
# Dave Page, EnterpriseDB

# Check the command line
if [ $# -ne 8 ]; 
then
    echo "Usage: $0 <SuperUsername> <Password> <Install dir> <Data dir> <Port> <Encoding> <case-insensitive> <flag>"
    exit 127
fi

SUPERNAME=`echo $1 | sed -e 's/^"//g' -e 's/"$//g'`
SUPERPASSWORD=`echo $2 | sed -e 's/^"//g' -e 's/"$//g'`
INSTALLDIR=`echo $3 | sed -e 's/^"//g' -e 's/"$//g'`
DATADIR=`echo $4 | sed -e 's/^"//g' -e 's/"$//g'`
PORT=`echo $5 | sed -e 's/^"//g' -e 's/"$//g'`
ENCODING=`echo $6 | sed -e 's/^"//g' -e 's/"$//g'`
FLAG=`echo $8 | sed -e 's/^"//g' -e 's/"$//g'`

# Exit code
WARN=0

# Error handlers
_die() {
    exit 1
}

_warn() {
    echo $1
    WARN=2
}

# Create the data directory, and set the appropriate permissions/owership
if [ ! -d "$DATADIR" ];
then
    mkdir -p "$DATADIR" || _die "Failed to create the data directory ($DATADIR)"
fi
case=""
if [ $7 -eq 1 ];
then
    case="--case-insensitive"
fi

# Initialise the database cluster
if [ "$FLAG"x = "R2"x ]; then
    LD_LIBRARY_PATH="$INSTALLDIR"/Server/lib "$INSTALLDIR"/Server/bin/initdb -W "$SUPERPASSWORD" -U "$SUPERNAME" -E "$ENCODING" -D "$DATADIR" $case|| _die "Failed to initialise the database cluster with initdb"
elif [ "$FLAG"x = "R3"x ]; then
    LD_LIBRARY_PATH="$INSTALLDIR"/Server/lib "$INSTALLDIR"/Server/bin/initdb -W "$SUPERPASSWORD" -U "$SUPERNAME" -E "$ENCODING" --lc-ctype="zh_CN.$ENCODING" --lc-collate="zh_CN.$ENCODING" -D "$DATADIR" $case|| _die "Failed to initialise the database cluster with initdb"
fi

if [ ! -d "$DATADIR/sys_log" ];
then
    mkdir "$DATADIR/sys_log" || _die "Failed to create the log directory ($DATADIR/sys_log)"
fi

if [ ! -f "~/.local/share/applications/kdb-console.desktop" ]; then
    cp $INSTALLDIR/desktops/kdb-*.desktop ~/.local/share/applications/
fi
# Edit the config files.
# Set the following in kingbase.conf:
#      listen_addresses = '*'
#      port = $PORT
#      log_destination = 'stderr'
#      logging_collector = on
#      log_line_prefix = '%t '
sed -i -e "s@#listen_addresses = 'localhost'@listen_addresses = '*'@g" \
      -e "s@#port = 54321@port = $PORT@g" \
      -e "s@#log_destination = 'stderr'@log_destination = 'stderr'@g" \
      -e "s@#logging_collector = off@logging_collector = on@g" \
      -e "s@#log_line_prefix = ''@log_line_prefix = '%t '@g" \
      "$DATADIR"/kingbase.conf || _warn "Failed to modify the kingbase.conf file ($DATADIR/kingbase.conf)"

echo "$0 ran to completion"
exit $WARN
