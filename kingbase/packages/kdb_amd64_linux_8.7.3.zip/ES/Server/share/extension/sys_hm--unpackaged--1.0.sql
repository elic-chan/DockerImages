DROP FUNCTION sys_healthy.check;
DROP TABLE sys_healthy.check_type;

DROP SCHEMA SYS_HEALTHY CASECAD;
