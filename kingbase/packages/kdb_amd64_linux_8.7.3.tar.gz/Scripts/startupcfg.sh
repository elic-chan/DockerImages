#!/bin/sh

# KingbaseES startup configuration script for Linux

# Check the command line
if [ $# -ne 5 ]; 
then
    echo "Usage: $0 <Major.Minor version> <Username> <Install dir> <Data dir> <ServiceName>"
    exit 127
fi

VERSION=$1
USERNAME=$2
INSTALLDIR=$3
DATADIR=$4
SERVICENAME=$5

# Exit code
WARN=0

# Error handlers
_die() {
    echo $1
    exit 1
}

_warn() {
    echo $1
    WARN=2
}

# Write the startup script
cat <<EOT > "/etc/init.d/$SERVICENAME"
#!/bin/bash
#
# chkconfig: 2345 85 15
### BEGIN INIT INFO
# Provides:          kingbase
# Required-Start:    \$syslog
# Required-Stop:     \$syslog
# Should-Start:      \$network \$time
# Should-Stop:       \$network \$time
# Default-Start:     2 3 4 5
# Default-Stop:      0 1 6
# Short-Description: Start and stop the kingbase server
# Description:       Starts and stops the KingbaseES $VERSION database server
### END INIT INFO

# Source function library.
if [ -f /etc/rc.d/functions ];
then
    . /etc/init.d/functions
fi

# KingbaseES Service script for Linux
curruser=\`whoami\`
start()
{
	echo \$"Starting KingbaseES $VERSION: "
	if [ "\$curruser"x == "root"x ];then
	    su - $USERNAME -c "LD_LIBRARY_PATH=$INSTALLDIR/Server/lib PATH=$INSTALLDIR/Server/bin:$PATH $INSTALLDIR/Server/bin/sys_ctl -w start -D \"$DATADIR\" -l \"$DATADIR/sys_log/startup.log\""
        else
            LD_LIBRARY_PATH=$INSTALLDIR/Server/lib PATH=$INSTALLDIR/Server/bin:$PATH $INSTALLDIR/Server/bin/sys_ctl -w start -D "$DATADIR" -l "$DATADIR/sys_log/startup.log"
	fi
	
	if [ \$? -eq 0 ];
	then
		echo "KingbaseES $VERSION started successfully"
                exit 0
	else
		echo "KingbaseES $VERSION did not start in a timely fashion, please see $DATADIR/sys_log/startup.log for details"
                exit 1
	fi
}

stop()
{
	echo \$"Stopping KingbaseES $VERSION: "
	if [ "\$curruser"x == "root"x ];then
	    su - $USERNAME -c "LD_LIBRARY_PATH=$INSTALLDIR/Server/lib PATH=$INSTALLDIR/Server/bin:$PATH $INSTALLDIR/Server/bin/sys_ctl stop -m fast -w -D \"$DATADIR\""
        else
            LD_LIBRARY_PATH=$INSTALLDIR/Server/lib PATH=$INSTALLDIR/Server/bin:$PATH $INSTALLDIR/Server/bin/sys_ctl stop -m fast -w -D "$DATADIR"
	fi
}

# See how we were called.
case "\$1" in
  start)
        start
        ;;
  stop)
        stop
        ;;
  restart|reload)
        stop
        sleep 3
        start
        ;;
  condrestart)
        if [ -f "$DATADIR/kingbase.pid" ]; then
            stop
            sleep 3
            start
        fi
        ;;
  status)
        su - $USERNAME -c "LD_LIBRARY_PATH=$INSTALLDIR/Server/lib PATH=$INSTALLDIR/Server/bin:$PATH $INSTALLDIR/Server/bin/sys_ctl status -D \"$DATADIR\""
        ;;
  *)
        echo \$"Usage: $0 {start|stop|restart|condrestart|status}"
        exit 1
esac

EOT

# Fixup the permissions on the StartupItems
chmod 0755 "/etc/init.d/$SERVICENAME" || _warn "Failed to set the permissions on the startup script (/etc/init.d/$SERVICENAME)"

# Configure the startup. On Redhat and friends we use chkconfig. On Debian, update-rc.d
# These utilities aren't entirely standard, so use both from their standard locations on
# each distro family. 
RET=`type /sbin/chkconfig > /dev/null 2>&1 || echo fail`
if [ ! $RET ];
then
    /sbin/chkconfig --add $SERVICENAME
	if [ $? -ne 0 ]; then
	    _warn "Failed to configure the service startup with chkconfig"
	fi
fi

RET=`type /usr/sbin/update-rc.d > /dev/null 2>&1 || echo fail`
if [ ! $RET ];
then
    /usr/sbin/update-rc.d $SERVICENAME defaults
	if [ $? -ne 0 ]; then
	    _warn "Failed to configure the service startup with update-rc.d"
	fi
fi

ldconfig > /dev/null 2>&1 || _warn "Failed to run ldconfig"

service kingbase8d start 

exit $WARN

