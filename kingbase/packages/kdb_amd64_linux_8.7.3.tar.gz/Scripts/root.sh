#!/bin/bash

ROOT_UID=0
INSTALLDIR=@@INSTALL_DIR@@
USERNAME=@@USER_NAME@@
DATADIR=@@DATA_DIR@@
VERSION=V8
SERVICENAME=kingbase8d

# Run as root, of course.
if [ x"$UID" !=  x"$ROOT_UID" ]
then
    echo "Must be root to run this script, and root.sh should be executed in the '$0' way, not 'sh $0'."
    exit 1
fi

$INSTALLDIR/Scripts/startupcfg.sh $VERSION $USERNAME $INSTALLDIR $DATADIR $SERVICENAME
