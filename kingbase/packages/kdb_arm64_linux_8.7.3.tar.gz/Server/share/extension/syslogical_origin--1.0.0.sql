\echo Use "CREATE EXTENSION syslogical_origin" to load this file. \quit
