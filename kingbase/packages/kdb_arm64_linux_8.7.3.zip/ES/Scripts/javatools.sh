#!/bin/bash

# get the jar name and arguments
appname=$1

if [ ! -e "$appname" ]; then
    echo "$appname dosn't exist"
    exit 1
elif [ ! -x "$appname" ]; then
    chmod +x "$appname"
fi

# change directory to the path of tools and run app
cd `dirname $appname` && ./`basename $appname`
