#!/bin/bash

ROOT_UID=0
SERVICENAME=kingbase8d

# Run as root, of course.
if [ x"$UID" !=  x"$ROOT_UID" ]
then
    echo "Must be root to run this script, and rootunistall.sh should be executed in the '$0' way, not 'sh $0'."
    exit 1
fi

# stop service
service $SERVICENAME stop &>/dev/null

# remove system services
RET=`type /sbin/chkconfig > /dev/null 2>&1 || echo fail`
if [ ! $RET ]; then
    /sbin/chkconfig --del $SERVICENAME &>/dev/null
fi
RET=`type /usr/sbin/update-rc.d > /dev/null 2>&1 || echo fail`
if [ ! $RET ]; then
    /usr/sbin/update-rc.d -f $SERVICENAME remove &>/dev/null
fi

rm -f /etc/init.d/$SERVICENAME
